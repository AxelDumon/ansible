export class Collection {
	name: 'cells' | 'agents';

	constructor(name: 'cells' | 'agents') {
		this.name = name;
	}

	// async function find<T>(id: String, rev:  String) : T{

	// async function find<T>(id: String, rev:  String) : T{
	//     try {
	//         const res = await fetch("azeaze", {
	//             headers: {"Authorization": "azea"
	//             }
	//         })
	//     }
	// }
}
