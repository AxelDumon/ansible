import { Agent } from "../Agent";
import { CouchManager } from "../BaseManager/CouchManager";
import { Cell } from "../Cell";
import { Document } from "../utils/couchTypes";
import { BaseRepository } from "./interfaces/BaseRepository";

export abstract class BasicCouchRepository<T extends (Cell | Agent) & Document>
  implements BaseRepository<T>
{
  protected baseManager: CouchManager;
  static designDocId: string;

  constructor(baseManager: CouchManager) {
    this.baseManager = baseManager;
  }
  deleteAll(): Promise<void> {
    throw new Error("Method not implemented.");
  }
  abstract count(): Promise<number>;
  abstract findAll(): Promise<T[]>;
  create(item: T): Promise<T> {
    item;
    throw new Error("Method not implemented.");
  }
  abstract update(id: string, item: Partial<T>): Promise<T | null>;
  deleteById(id: string): Promise<boolean> {
    id;
    throw new Error("Method not implemented.");
  }
}
